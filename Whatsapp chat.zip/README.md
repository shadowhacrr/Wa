# WhatsApp Chat App - Pakistani Contacts

Complete WhatsApp-style chat application with 10 Pakistani contacts (6 female + 4 male) featuring realistic lover-style conversations.

---

## Features

- **10 Unique Chats** - Each with different personality and conversation style
- **WhatsApp UI** - Exact WhatsApp-like design with green theme
- **Green Double Ticks** - Messages show seen status (blue double checkmarks)
- **Typing Indicator** - Shows "typing..." when auto-reply is generating
- **Online Status** - Green dot for online contacts
- **Unread Badges** - Message count badges on chat list
- **Auto-Reply System** - Each contact has unique responses based on personality
- **JSON Storage** - No database needed, all data stored in JSON files
- **Search** - Search chats by name or message content

---

## Characters & Personalities

### Female Contacts (6):
1. **Zara** - Overly romantic, attached, emotional "jaan" type
2. **Ayesha** - Shy, traditional, polite, uses "Aap"
3. **Hina** - Bubbly, energetic, teasing, modern slang
4. **Sara** - Stylish, attitude, English mix, modern girl
5. **Mehwish** - Poetic, Shayari type, deep romantic Urdu poetry
6. **Fatima** - Innocent, cute, childish love, blushing type

### Male Contacts (4):
7. **Ali** - Confident, flirty, charming, dominant
8. **Hassan** - Strong, protective, caring, supportive
9. **Usman** - Funny, playful, roasting, best-friend energy
10. **Bilal** - Calm, mature, intellectual, night owl

---

## Project Structure

```
whatsapp-chat-app/
  server.js              # Main Node.js/Express server
  package.json           # Dependencies & scripts
  vercel.json            # Vercel deployment config
  README.md              # This file
  data/
    chats.json           # Chat metadata & last messages
    messages/            # Individual chat message files
  public/
    index.html           # Chat list page
    chat.html            # Individual chat page
    css/
      style.css          # WhatsApp-style CSS
    js/
      index.js           # Chat list logic
      chat.js            # Chat page logic
    images/
      dp1.jpg - dp10.jpg # Profile pictures
```

---

## Local Development

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start Server
```bash
npm start
```

### Step 3: Open Browser
```
http://localhost:3000
```

---

## Customization Guide

### Adding New Contacts

1. Open `server.js`
2. Find `initChats()` function (around line 47)
3. Add new contact object to `initialChats` array:

```javascript
{
  id: 11,
  name: "New Name ✨",
  dp: "/images/dp11.jpg",     // Add your image to public/images/
  status: "online",
  about: "Status text",
  lastMessage: "Initial message...",
  lastMessageTime: "10:00 PM",
  unread: 1,
  isOnline: true,
  gender: "female"
}
```

4. Add initial messages in `getInitialMessages()` function (around line 173):

```javascript
11: [ // New Contact - Personality description
  { id: 1, sender: "them", text: "Hello message...", time: "10:00 PM", seen: false }
]
```

5. Add auto-replies in `getAutoReply()` function (around line 231):

```javascript
11: [ // New Contact
  "Reply message 1...",
  "Reply message 2...",
  "Reply message 3..."
]
```

6. Restart the server

### Changing Contact Names

Edit `data/chats.json` file or modify the `initialChats` array in `server.js`.

### Changing Profile Pictures

Replace images in `public/images/` folder. Name them `dp1.jpg` to `dp10.jpg`.
Recommended size: 400x400 pixels, square format.

### Changing Conversation Style

Edit auto-replies in `getAutoReply()` function in `server.js`. Each contact has an array of possible replies - the system picks a random one.

### Modifying Initial Messages

Edit the `getInitialMessages()` function in `server.js` or directly modify files in `data/messages/` folder.

---

## Deployment Guide

### Option 1: Vercel (Recommended - FREE)

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Login to Vercel:
```bash
vercel login
```

3. Deploy:
```bash
vercel
```

4. Follow prompts - select your account, project name, and confirm settings.

The `vercel.json` file is already configured for this project.

### Option 2: Render (FREE)

1. Go to [render.com](https://render.com) and signup
2. Click "New +" → "Web Service"
3. Connect your GitHub repo or upload code
4. Settings:
   - **Name**: whatsapp-chat
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Plan**: Free
5. Click "Create Web Service"

### Option 3: Railway (FREE)

1. Go to [railway.app](https://railway.app) and signup
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your repository
4. Railway auto-detects Node.js - just deploy!

### Option 4: Heroku

1. Install Heroku CLI
2. Login:
```bash
heroku login
```

3. Create app:
```bash
heroku create your-app-name
```

4. Deploy:
```bash
git init
git add .
git commit -m "Initial commit"
git push heroku main
```

### Option 5: Any VPS / Server (DigitalOcean, Linode, etc.)

1. Upload project files to server
2. Install Node.js:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

3. Install PM2 (process manager):
```bash
npm i -g pm2
```

4. Start app:
```bash
cd whatsapp-chat-app
npm install
pm2 start server.js --name "whatsapp-chat"
pm2 save
pm2 startup
```

5. (Optional) Setup Nginx reverse proxy for domain

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| PORT | 3000 | Server port |

To set on Linux/Mac:
```bash
export PORT=8080
npm start
```

To set on Windows:
```cmd
set PORT=8080
npm start
```

---

## Resetting All Chats

To reset to initial state, delete the data folder:
```bash
rm -rf data/
```

Then restart the server - it will recreate default chats and messages.

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/chats | Get all chats |
| GET | /api/chats/:id | Get single chat |
| GET | /api/chats/:id/messages | Get messages |
| POST | /api/chats/:id/messages | Send message + get reply |
| POST | /api/chats/:id/seen | Mark messages as seen |

---

## Tech Stack

- **Backend**: Node.js + Express
- **Frontend**: HTML + CSS + JavaScript (Vanilla)
- **Storage**: JSON Files (no database)
- **Styling**: WhatsApp-like CSS with custom properties

---

## License

This project is for educational purposes.
